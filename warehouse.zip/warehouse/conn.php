
<?php
	mysql_connect("localhost","root","");
	mysql_select_db("warehouse");
	date_default_timezone_set("Asia/Bangkok");
?>